import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class LeituraArquivoTexto {

	public static void main(String[] args) {
		File arquivo = new File("texto.txt");
		try {
			Scanner streamEntrada = new Scanner(arquivo);
			
			while(streamEntrada.hasNextLine()){
				String linha = streamEntrada.nextLine();
				System.out.println(linha);
			}
			
			streamEntrada.close();
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		

	}

}
