import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;

public class ExemploArquivosTexto {

	public static void main(String[] args){
		
		Scanner teclado = new Scanner(System.in);
		System.out.print("Informe o nome de um arquivo: ");
		String arquivo = teclado.nextLine();

		// Verifica se o arquivo existe
		File objFileEntrada = new File(arquivo);
		if (objFileEntrada.exists()){
			
			// Busca cada uma das linhas do arquivo e grava em 
			//   um arquivo de saida 
			File objFileSaida = new File(arquivo + ".out");
			try {
				Scanner streamEntrada = new Scanner(objFileEntrada);
				PrintWriter streamSaida = new PrintWriter(objFileSaida);
				
				while(streamEntrada.hasNextLine()){
					String linha = streamEntrada.nextLine();
					streamSaida.println(linha);
					System.out.println(linha);
				}
				
				streamEntrada.close();
				streamSaida.close();
				System.out.println("Arquivo copiado.");

			} catch (FileNotFoundException e) {
				e.printStackTrace();
			}
			
		} else {
			System.out.println("Arquivo nao existe");
		}
		
		
	}
}
