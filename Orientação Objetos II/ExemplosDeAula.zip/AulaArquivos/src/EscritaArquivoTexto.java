import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;

public class EscritaArquivoTexto {

	public static void main(String[] args) {

		File arquivo = new File("texto.txt");
		PrintWriter streamSaida = null;
		try {
			streamSaida = new PrintWriter(arquivo);
			streamSaida.println("Tales Viegas");
			streamSaida.print("Professor\n");
			streamSaida.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} finally {
			if (streamSaida != null){
				streamSaida.close();
			}
		}
		
	}

}
