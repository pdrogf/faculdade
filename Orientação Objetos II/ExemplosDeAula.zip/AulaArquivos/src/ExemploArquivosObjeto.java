import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Scanner;

public class ExemploArquivosObjeto {

	public static void main(String[] args){
		
		Scanner teclado = new Scanner(System.in);
		System.out.print("Informe o nome do arquivo de professores: ");
		String arquivo = teclado.nextLine();

		// Verifica se o arquivo existe
		File objFileEntrada = new File(arquivo);
		if (objFileEntrada.exists()){
			
			// Arquivo ja existe, entao exibe os dados dos professores
			try {
				ObjectInputStream inputStream = new ObjectInputStream(new FileInputStream(objFileEntrada));
				ArrayList<Professor> listaProfessores = (ArrayList<Professor>)inputStream.readObject();
				
				for(Professor p : listaProfessores){
					System.out.println(p.getNome() + " - " + p.getCgu());
				}
				
				inputStream.close();
			} catch (IOException | ClassNotFoundException e) {
				e.printStackTrace();
			}
			
		} else {
			
			// Arquivo nao existe. Coloca alguns professores nele
			ArrayList<Professor> professores = new ArrayList<Professor>();
			for (int i=1; i < 5; i++){
				professores.add(new Professor("Professor " + i, i));
			}
			
			try {
				ObjectOutputStream streamSaida = new ObjectOutputStream(new FileOutputStream(objFileEntrada));
				streamSaida.writeObject(professores);
				streamSaida.close();
				System.out.println("Arquivo criado.");
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		
	}
	
}
