
public class Teste {

	public static void main(String[] args){
		
		Professor p = new Professor("Tales", 10);
		p.getCgu();
		
		
	}
	
}
