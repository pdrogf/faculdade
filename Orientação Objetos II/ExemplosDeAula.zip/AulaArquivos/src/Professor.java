import java.io.Serializable;

public class Professor implements Serializable {

	private static final long serialVersionUID = -8673733189417592071L;
	private String nome;
	private int cgu;
	
	Professor(String nome, int cgu){
		this.setNome(nome);
		this.setCgu(cgu);
	}
	
	public String getNome() {
		return nome;
	}
	
	public void setNome(String nome) {
		this.nome = nome;
	}
	
	public int getCgu() {
		return cgu;
	}
	
	public void setCgu(int cgu) {
		this.cgu = cgu;
	}	
}
