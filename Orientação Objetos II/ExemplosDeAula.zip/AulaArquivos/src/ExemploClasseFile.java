import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class ExemploClasseFile {

	public static void main(String[] args) {

		Scanner teclado = new Scanner(System.in);
		System.out.print("Informe o nome de um arquivo: ");
		String arquivo = teclado.nextLine();
		
		// Cria o objeto File
		File objFile = new File(arquivo);
		
		// Verifica se o arquivo existe
		if (objFile.exists()){
			System.out.println("O arquivo existe");
		} else {
			System.out.println("O arquivo nao existe. Vou criar um vazio.");
			try {
				objFile.createNewFile();
				System.out.println("Arquivo criado com sucesso!");
			} catch (IOException e) {
				System.out.println("Impossivel criar arquivo");
				e.printStackTrace();
			}
		}

		// Verifica se o arquivo eh uma pasta
		if (objFile.isDirectory()){
			System.out.println("O arquivo é uma pasta. Vou listar os arquivos dele");
			String[] listaArquivos = objFile.list();
			for (String arq : listaArquivos){
				System.out.println(arq);
			}
		} else {
			
			System.out.println("Alguns dados do arquivo: ");
			System.out.println("Tamanho: " + objFile.length());
			System.out.println("Caminho: " + objFile.getAbsolutePath());
		}
		
	}

}
