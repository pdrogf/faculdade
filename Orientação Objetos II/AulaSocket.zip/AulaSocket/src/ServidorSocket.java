import java.util.*;
import java.io.*;
import java.net.*;

public class ServidorSocket {

	public static void main(String[] args) {
		try {
			// Instancia o servidor
			ServerSocket server = new ServerSocket(8080);
			// Conecta no servidor
			Socket s = server.accept();
			// Busca streams de E/S
			Scanner entrada = new Scanner(new InputStreamReader(s.getInputStream()));
			PrintWriter saida = new PrintWriter(s.getOutputStream());
			// Imprime requisicao
			String linha;
			while ((linha = entrada.nextLine()) != null) {
				if (linha.length() == 0) {
					break;
				}
				System.out.println(linha);
			}
			// Envia dados atraves do Stream
			saida.println("Recebi requisicao\n");
			saida.flush();
			// Encerra recursos
			entrada.close();
			saida.close();
			s.close();
		} catch (UnknownHostException ex) {
			System.out.println("Host desconhecido");
		} catch (IOException ex) {
			System.out.println("Erro na conexao: " + ex.getMessage());
		}
	}
}
