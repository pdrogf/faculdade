import java.net.*;
import java.io.*;
import java.util.*;

public class ClienteSocket {

	public static void main(String[] args) {
		try {
			// Conecta no servidor
			Socket s = new Socket("localhost", 8080);
			// Busca streams de E/S
			Scanner entrada = new Scanner(new InputStreamReader(s.getInputStream()));
			PrintWriter saida = new PrintWriter(s.getOutputStream());
			// Envia dados atraves do Stream
			saida.println("GET / HTTP/1.1\nHost: www.ulbra.br\n");
			saida.flush();
			// Imprime retorno
			String linha;
			while ((linha = entrada.nextLine()) != null) {
				System.out.println(linha);
			}
			// Encerra recursos
			entrada.close();
			saida.close();
			s.close();
		} catch (UnknownHostException ex) {
			System.out.println("Host desconhecido");
		} catch (IOException ex) {
			System.out.println("Erro na conexao: " + ex.getMessage());
		}
	}

}
